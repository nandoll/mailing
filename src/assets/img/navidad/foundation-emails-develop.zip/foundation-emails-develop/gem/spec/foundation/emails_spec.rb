require "spec_helper"

describe FoundationEmails do
  it "has a version number" do
    expect(FoundationEmails::VERSION).not_to be nil
  end
end
