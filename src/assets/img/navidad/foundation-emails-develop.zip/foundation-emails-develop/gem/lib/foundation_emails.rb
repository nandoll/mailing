require "foundation_emails/version"
require "foundation_emails/engine"

module FoundationEmails

end
